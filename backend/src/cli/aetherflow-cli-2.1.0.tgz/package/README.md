# AetherFlow CLI

The official command-line interface for AetherFlow - the durable long-running workflow engine.

## Installation

### npm (Recommended)
```bash
npm install -g aetherflow-cli
```

### yarn
```bash
yarn global add aetherflow-cli
```

### Direct Download
```bash
# macOS
curl -L https://github.com/aetherflow/cli/releases/latest/download/aetherflow-macos -o aetherflow
chmod +x aetherflow
sudo mv aetherflow /usr/local/bin/

# Linux
curl -L https://github.com/aetherflow/cli/releases/latest/download/aetherflow-linux -o aetherflow
chmod +x aetherflow
sudo mv aetherflow /usr/local/bin/

# Windows
curl -L https://github.com/aetherflow/cli/releases/latest/download/aetherflow-windows.exe -o aetherflow.exe
.\aetherflow.exe install
```

## Quick Start

1. **Initialize a project**
```bash
aetherflow init
```

2. **Authenticate**
```bash
aetherflow auth login --api-key your_api_key_here
```

3. **Deploy a template**
```bash
aetherflow deploy payment-recovery
```

4. **List workflows**
```bash
aetherflow workflows list
```

## Commands

### Authentication
```bash
# Login with API key
aetherflow auth login --api-key your_key

# OAuth authentication
aetherflow auth login --oauth

# Check status
aetherflow auth status

# Logout
aetherflow auth logout
```

### Workflows
```bash
# List workflows
aetherflow workflows list

# Get workflow details
aetherflow workflows get <workflow-id>

# Create workflow
aetherflow workflows create --name "My Workflow" --file workflow.json

# Run workflow
aetherflow workflows run <workflow-id> --data '{"input": "value"}'

# Delete workflow
aetherflow workflows delete <workflow-id>
```

### Executions
```bash
# List executions
aetherflow executions list

# Get execution details
aetherflow executions get <execution-id>

# Watch execution in real-time
aetherflow executions watch <execution-id>

# Cancel execution
aetherflow executions cancel <execution-id>
```

### Templates
```bash
# List templates
aetherflow templates list

# Use template
aetherflow templates use approval-workflow --name "My Approval"

# Show template details
aetherflow templates show approval-workflow
```

### Configuration
```bash
# Set API URL
aetherflow config set api_url https://api.aetherflow.com

# View configuration
aetherflow config list

# Reset configuration
aetherflow config reset
```

### Bulk Operations
```bash
# Bulk execute workflows
aetherflow bulk run --workflow-id <id> --inputs-file inputs.json

# Export workflows
aetherflow bulk export --format json --output workflows.json

# Import workflows
aetherflow bulk import --file workflows.json
```

### Environment Management
```bash
# List environments
aetherflow env list

# Switch environment
aetherflow env use production

# Set environment variable
aetherflow env set DATABASE_URL postgres://localhost/db
```

### Monitoring
```bash
# System status
aetherflow monitoring status

# View metrics
aetherflow monitoring metrics

# View logs
aetherflow monitoring logs
```

### Utilities
```bash
# Show version
aetherflow utils version

# Generate completion script
aetherflow utils completion bash

# Run diagnostics
aetherflow utils doctor

# Clean cache
aetherflow utils clean --cache
```

## Global Options

```bash
# Enable debug mode
aetherflow --debug <command>

# Verbose output
aetherflow --verbose <command>

# Specify configuration file
aetherflow --config ~/.aetherflow.yaml <command>

# Specify API URL
aetherflow --api-url https://api.aetherflow.com <command>

# Specify workspace
aetherflow --workspace my-workspace <command>
```

## Configuration

Create a `.aetherflow` configuration file in your project root:

```yaml
# .aetherflow
api_url: https://api.aetherflow.com
workspace: my-workspace
default_environment: development

environments:
  development:
    api_url: http://localhost:8459
  production:
    api_url: https://api.aetherflow.com

workflows:
  auto_discover: true
  paths:
    - ./workflows
    - ./src/workflows
```

## Shell Completions

### Bash
```bash
# Add to ~/.bashrc
eval "$(aetherflow completion bash)"
```

### Zsh
```bash
# Add to ~/.zshrc
eval "$(aetherflow completion zsh)"
```

### Fish
```bash
# Add to ~/.config/fish/config.fish
aetherflow completion fish | source
```

## Examples

### Payment Recovery Workflow
```bash
# Deploy payment recovery template
aetherflow deploy payment-recovery

# Monitor execution
aetherflow executions watch --follow

# Check status
aetherflow monitoring status
```

### Custom Workflow
```bash
# Create from file
aetherflow workflows create --file my-workflow.json

# Run with data
aetherflow workflows run wf_001 --data '{"amount": 99.99, "currency": "USD"}'

# Watch execution
aetherflow executions watch exec_123 --logs
```

### Bulk Operations
```bash
# Export all workflows
aetherflow bulk export --format json --output backup.json

# Import to new workspace
aetherflow bulk import --file backup.json --workspace new-project
```

## Troubleshooting

### "API key not found"
```bash
# Check if API key is set
aetherflow config list

# Set API key
aetherflow auth login --api-key your_key
```

### "Connection timeout"
```bash
# Check API URL
aetherflow config get api_url

# Set custom timeout
aetherflow config set timeout 30
```

### "Permission denied"
```bash
# Check file permissions
ls -la $(which aetherflow)

# Reinstall with proper permissions
npm uninstall -g aetherflow-cli
sudo npm install -g aetherflow-cli
```

## Development

### Building from Source
```bash
git clone https://github.com/aetherflow/cli.git
cd cli
npm install
npm run build
npm link
```

### Running Tests
```bash
npm test
```

### Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT © [AetherFlow Team](https://aetherflow.com)

## Support

- **Documentation**: [https://docs.aetherflow.com](https://docs.aetherflow.com)
- **Issues**: [GitHub Issues](https://github.com/aetherflow/cli/issues)
- **Discord**: [Join our Discord](https://discord.gg/aetherflow)
- **Email**: [support@aetherflow.com](mailto:support@aetherflow.com)

---

Built with durability in mind. 🚀
